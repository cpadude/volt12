<?php

namespace ClickerVolt;

require_once __DIR__ . '/tableStatsWholePathVarX.php';

TableStats::registerClass('ClickerVolt\\TableStatsWholePathVar9');
class TableStatsWholePathVar9 extends TableStatsWholePathVarX
{

    public function getVarNumber()
    {
        return 9;
    }
}
