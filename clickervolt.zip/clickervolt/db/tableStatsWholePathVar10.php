<?php

namespace ClickerVolt;

require_once __DIR__ . '/tableStatsWholePathVarX.php';

TableStats::registerClass('ClickerVolt\\TableStatsWholePathVar10');
class TableStatsWholePathVar10 extends TableStatsWholePathVarX
{

    public function getVarNumber()
    {
        return 10;
    }
}
