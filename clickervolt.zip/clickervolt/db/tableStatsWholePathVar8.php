<?php

namespace ClickerVolt;

require_once __DIR__ . '/tableStatsWholePathVarX.php';

TableStats::registerClass('ClickerVolt\\TableStatsWholePathVar8');
class TableStatsWholePathVar8 extends TableStatsWholePathVarX
{

    public function getVarNumber()
    {
        return 8;
    }
}
